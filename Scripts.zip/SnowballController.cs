using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SnowballController : MonoBehaviour
{
    public Animator myAnimator;
    private Rigidbody2D rigidBody2D;
    public Player_movement playController;
    public Player2_movement play2Controller;

    // Start is called before the first frame update
    void Start()
    {
        myAnimator = GetComponent<Animator>();
        rigidBody2D = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player_1" || collision.gameObject.tag == "Player_2")
        {
            rigidBody2D.velocity = new Vector2(0, 0);
            rigidBody2D.freezeRotation = true;
            
            if (collision.gameObject.tag == "Player_1")
            {
                playController = collision.gameObject.GetComponent<Player_movement>();
                playController.speed = playController.speed * 0.5f;
            }
            else // Player 2 is hit
            {
                play2Controller = collision.gameObject.GetComponent<Player2_movement>();
                play2Controller.speed = play2Controller.speed * 0.5f;
            }
            Destroy(this.gameObject);
        }

        if (collision.collider.name == "Ground")
        {
            rigidBody2D.velocity = new Vector2(0, 0);
            rigidBody2D.freezeRotation = true;
            Destroy(this.GetComponent<Collider2D>());
            this.gameObject.AddComponent<PolygonCollider2D>();
        }

    }

}
