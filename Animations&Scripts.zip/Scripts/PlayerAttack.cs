using UnityEngine;


public class PlayerAttack : MonoBehaviour
{

    private Animator anim;
    private Player_movement playerMovement;

    // Will set cool down period
    [SerializeField] private float AttackCoolDown;

    // Position from which bulletes will be fired.
    [SerializeField] private Transform FirePoint;

    [SerializeField] private GameObject[] Bolts;

    // Initializing cool down timer to infinity to be able to use gun as soon as game starts
    private float CoolDownTimer = Mathf.Infinity;

    private void Awake()
    {
        // getComponent gives us acess to Rigidbody2D
        playerMovement = GetComponent<Player_movement>();

        // getComponent gives us acess to Animator
        anim = GetComponent<Animator>();

    }


    // Update is called once per frame
    void Update()
    {

        if (Input.GetKey(KeyCode.E) && CoolDownTimer > AttackCoolDown)
        {
            Attack();
        }
        // Time.deltaTime is the interval in seconds from the last frame to the current one
        CoolDownTimer += Time.deltaTime;
    }

    private void Attack()
    {
        anim.SetTrigger("attack");
        CoolDownTimer = 0;
        Bolts[FindBolts()].transform.position = FirePoint.position;
        Bolts[FindBolts()].GetComponent<Projectile>().SetDirection(Mathf.Sign(transform.localScale.x));
    }

    private int FindBolts()
    {
        for (int i = 0; i < Bolts.Length; i++)
        {
            if (!Bolts[i].activeInHierarchy)
                return i;
        }
        return 0;
    }

}
