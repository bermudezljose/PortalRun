using UnityEngine;

public class Player2_movement : MonoBehaviour
{
    // Creating a 2D rigid body reference.
    private Rigidbody2D body;

    // Creating variable to give us access to our animator component
    private Animator anim;

    // Creating bool variable to be used as animation transition parameter
    private bool grounded;

    // Creating bool variable to be used as animation transition parameter
    private bool running;

    // Creating speed variable to scale the X velocity of player
    // [SerializeField] allows us to directly edit variable from unity. (Added to script section)
    [SerializeField] private float speed;

    // Creating jumpSpeed variable to scale the Y velocity of player
    [SerializeField] private float jumpSpeed;
    
    // Awake is called when script instance is being loaded (every time we start the game)
    private void Awake()
    {
        // getComponent gives us acess to Rigidbody2D
        body = GetComponent<Rigidbody2D>();

        // getComponent gives us acess to Animator
        anim = GetComponent<Animator>();

        // This will stop the rotation of players when colliding against one another.
        body.freezeRotation = true;
    }


    // Update is called once per frame
    private void Update()
    {
        // Implementing of player 2 horizontal movement using arrows
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            body.AddForce(Vector3.left * speed);
            transform.localScale = new Vector3(-1,1,1); // Flip player when moving left.
            running = true;

        }
        else if (Input.GetKey(KeyCode.RightArrow))
        {
            body.AddForce(Vector3.right * speed);
            transform.localScale = new Vector3(1,1,1); // Flip player when moving right.
            running = true;
        }
        else
        {
            running = false;
        }

        // Implementing Jump mechanic
        if(Input.GetKeyDown(KeyCode.UpArrow) && grounded == true) // If space key is pressed this conditional is triggered.
        {
            Jump(); // Jump function called.
        }

        // Set animator parameters
        anim.SetBool("run", running); // paramater name must be exactly as we named it in unity. 
        // For the above when arrows keys aren't pressed (horizonatl input = 0 since there's no input) then run is set to false (0 != 0 is false)
        // When arrows keys aren pressed (horizonatl input != 0 since there is input) then run is set to true (0 != 0 is true)

        anim.SetBool("grounded", grounded);

    }

    // Function to deal with jumping mechanics.
    void Jump()
    {
        body.velocity = new Vector2(body.velocity.x, jumpSpeed); // x velocity remains unchanged, y velocity is affected by jumpSpeed variable.
        grounded = false; // player is jumping so not grounded
    }

    // OnCollisionEnter2D is called when this rigid body/collider touches another rigid body/collider
    void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Ground") // Conditional runs if the object tagged is tagged as "Ground"
        {
            grounded = true;
        }
    }

}

